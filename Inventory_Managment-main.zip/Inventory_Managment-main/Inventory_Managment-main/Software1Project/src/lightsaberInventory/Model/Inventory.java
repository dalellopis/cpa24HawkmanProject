package lightsaberInventory.Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;



public class Inventory {


    private static final ObservableList<Part> allParts = FXCollections.observableArrayList(
            new Outsourced(1, "", 1, 6, 0 , 5000, ""),
            new Outsourced(2, "", 1, 5, 0, 5000, ""),
            new Outsourced(3, "", 1, 4, 0, 500, ""),
            new InHouse(4, "", 1, 1, 0, 5000,2),
            new InHouse(5, "", 1, 1, 0, 5000, 1),
            new InHouse(6, "", 1, 1, 0, 5000, 2),
            new InHouse(7, "", 1, 1, 0, 5000, 1)

    );


    private static ObservableList<Part> GuardianParts = FXCollections.observableArrayList(
            lookupPart(1),
            lookupPart(4),
            lookupPart(5),
            lookupPart(6),
            lookupPart(7)
    );


    private static ObservableList<Part> CounselorParts = FXCollections.observableArrayList(
            lookupPart(2),
            lookupPart(4),
            lookupPart(5),
            lookupPart(6),
            lookupPart(7)
    );

    private static ObservableList<Part> SithParts = FXCollections.observableArrayList(
            lookupPart(3),
            lookupPart(4),
            lookupPart(5),
            lookupPart(6),
            lookupPart(7)
    );


    private static ObservableList<Product> allProducts = FXCollections.observableArrayList(
            new Product(1001, "", 7000, 5, 0, 5000, GuardianParts),
            new Product(1002, "", 5000, 4,0,5000, CounselorParts),
            new Product(1003, "", 6000, 6, 0, 5000, SithParts)
    );



    public static void addPart(Part newPart) {
        allParts.add(newPart);
    };


    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    };


    public static Part lookupPart(int partID) {
        for(Part part : allParts) {
            if (part.getId() == partID) {
                return part;
            }
        }
        return null;
    };


    public static Product lookupProduct(int productID){
        for(Product prod  : allProducts) {
            if (prod.getId() == productID) {
                return prod;
            }
        }
        return null;
    };

    public static ObservableList<Part> lookupPart(String partName){
        ObservableList<Part> filteredPartsList = FXCollections.observableArrayList();
        for (Part p : allParts) {
            if (partName.compareTo(p.getName()) == 0) {
                filteredPartsList.add(p);
            }
        }
        return filteredPartsList;

    };


    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> filteredProductList = FXCollections.observableArrayList();
        for (Product p : allProducts) {
            if (productName.compareTo(p.getName()) == 0) {
                filteredProductList.add(p);
            }
        }
        return filteredProductList;

    };


    public static void updatePart(int index, Part selectedPart) {
        allParts.set(index - 1, selectedPart);
    };


    public static void updateProduct(int index, Product newProduct){
        allProducts.set(index, newProduct);
    }




    public static boolean deletePart(Part selectedPart) {
        int id = selectedPart.getId();
        Part lookupPart = lookupPart(id);

        return allParts.remove(lookupPart);
    };


    public static boolean deleteProduct(Product selectedProduct) {
        int id = selectedProduct.getId();
        Product lookupProduct = lookupProduct(id);
        return allProducts.remove(lookupProduct);
    }


    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }



    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }


}
