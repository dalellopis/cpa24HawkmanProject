package lightsaberInventory.Model;


public class InHouse extends Part {

    private int machineID;


    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineID = machineId;
    };



    public void setMachineId(int machineID) {
        this.machineID = machineID;
    }


    public int getMachineId() {
        return machineID;
    };


}
